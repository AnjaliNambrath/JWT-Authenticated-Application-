const express = require("express");
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const cors = require("cors");
require("colors");
User = require('./models/userModel')
jsonwebtoken = require("jsonwebtoken");

const app = express();
app.use(express.static('./public'));

app.use(cors());

mongoose.connect('mongodb://localhost:27017/FlightManagement')
console.log("MongoDB Connection Successful".yellow.underline.bold);

app.use(bodyParser.json())
app.use(express.urlencoded({ extended: false }));

app.use(function(req, res, next) {
  if (req.headers && req.headers.authorization && req.headers.authorization.split(' ')[0] === 'JWT') {
    jsonwebtoken.verify(req.headers.authorization.split(' ')[1], 'RESTFULAPIs', function(err, decode) {
      if (err) req.user = undefined;
      req.user = decode;
      next();
    });
  } else {
    req.user = undefined;
    next();
  }
});

var routes = require('./route/userRoute');
routes(app);

app.use(function(req, res) {
  res.status(404).send({ url: req.originalUrl + ' not found' })
});

app.listen(5000,()=>{
    console.log("Server Listening on port 5000".red.underline.bold);
})
